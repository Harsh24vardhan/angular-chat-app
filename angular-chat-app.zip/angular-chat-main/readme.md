# Fullstack chat app
## Angular for Front and Nodejs for Back

### Install + Dev servers start
1. Clone repository
`git clone https://github.com/aIv4ro/angular-chat.git`
2. Install dependencies
`pnpm install`
3. Start dev servers
`pnpm run dev:server`
`pnpm run dev:front`