import { ToSrcPipe } from './to-src.pipe'

describe('ToSrcPipe', () => {
  it('create an instance', () => {
    const pipe = new ToSrcPipe()
    expect(pipe).toBeTruthy()
  })
})
